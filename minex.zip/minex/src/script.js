function post() {
  let n = name.value;
  let m = message.value;

  if (!n || !m) return alert("Type name and message!");

  let posts = JSON.parse(localStorage.getItem("posts") || "[]");

  posts.unshift({
    name: n,
    message: m,
    time: new Date().toLocaleString()
  });

  localStorage.setItem("posts", JSON.stringify(posts));

  name.value = "";
  message.value = "";

  show();
}

function show() {
  let posts = JSON.parse(localStorage.getItem("posts") || "[]");
  feed.innerHTML = posts.map(p => `
    <div class="post">
      <div class="name">${p.name}</div>
      <div>${p.message}</div>
      <small>${p.time}</small>
    </div>
  `).join("");
}

show();